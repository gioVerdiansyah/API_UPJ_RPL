<!DOCTYPE html>
<html lang="en">

<head>
    <title>Table V04</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">

    <meta name="robots" content="noindex, follow">
</head>

<body>
    <div class="container-table100">
        <div class="wrap-table100">
            <div class="table100 ver1 m-b-110">
                <div class="table100-head">
                    <table>
                        <thead>
                            <tr class="row100 head">
                                <th class="cell100 column1 text-center">Jenis <br> Pembelian</th>
                                <th class="cell100 column5 text-center">Tanggal <br> Pembelian</th>
                                <th class="cell100 column2">Harga Bahan</th>
                                <th class="cell100 column3">Harga Jasa</th>
                                <th class="cell100 column4">Total</th>
                                <th class="cell100 column4">Tipe Pembayaran</th>
                            </tr>
                        </thead>
                    </table>
                </div>
                <div class="table100-body js-pscroll">
                    <table>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $dataTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="row100 body">
                                    <td class="cell100 column1 pt-5"><?php echo e($item->jenis); ?></td>
                                    <td class="cell100 column2 pt-5"><?php echo e($item->created_at->format('d/m/Y H:i')); ?></td>
                                    <td class="cell100 column3 pt-5"><?php echo e($item->harga_bahan); ?></td>
                                    <td class="cell100 column4 pt-5"><?php echo e($item->harga_jasa); ?></td>
                                    <td class="cell100 column5 pt-5"><?php echo e($item->total); ?></td>
                                    <td class="cell100 column5 pt-5"><?php echo e($item->tipe_pembayaran); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="row100 body">
                                    <td rowspan="5" class="cell100 column1 text-center pt-5">Belum ada data
                                        transaksi</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script>
        window.onload = function() {
            window.print();
            window.onafterprint = function() {
                window.close();
                window.history.back();
            };
        };
    </script>
</body>

</html>
<?php /**PATH D:\Document\API\upj_rpl\resources\views/cetak.blade.php ENDPATH**/ ?>